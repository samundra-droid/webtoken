package com.example.webtoken;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebtokenApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebtokenApplication.class, args);
	}

}
